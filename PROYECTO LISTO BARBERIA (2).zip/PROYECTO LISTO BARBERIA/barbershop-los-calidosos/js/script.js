// =====================================================
// Barber Shop Los Calidosos - JavaScript
// =====================================================


// ===== 1. PANTALLA DE CARGA =====
// Se oculta cuando la página termina de cargar.
// Si algo demora mucho, igual se oculta a los 3.5 segundos.
function hideLoader() {
  const loader = document.getElementById('loader');
  if (loader) {
    loader.classList.add('hidden');
  }
}

window.addEventListener('load', () => setTimeout(hideLoader, 900), { once: true });
setTimeout(hideLoader, 3500);


// ===== 2. BARRA DE NAVEGACIÓN =====
// Cuando se baja un poco la página, la barra se pone con fondo oscuro.
const nav = document.getElementById('nav');

window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });


// ===== 3. MENÚ PARA CELULAR =====
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');

// Abre o cierra el menú
function toggleMenu() {
  hamburger.classList.toggle('open');
  mobileMenu.classList.toggle('open');
  hamburger.setAttribute('aria-expanded', mobileMenu.classList.contains('open'));

  // Mientras el menú está abierto no se puede hacer scroll en la página
  document.body.style.overflow = mobileMenu.classList.contains('open') ? 'hidden' : '';
}

// Cierra el menú
function closeMenu() {
  hamburger.classList.remove('open');
  hamburger.setAttribute('aria-expanded', 'false');
  mobileMenu.classList.remove('open');
  document.body.style.overflow = '';
}

// Clic en el botón hamburguesa
hamburger.addEventListener('click', toggleMenu);

// Clic en cualquier enlace del menú: se cierra
document.querySelectorAll('.mobile-menu-link').forEach((link) => {
  link.addEventListener('click', closeMenu);
});

// Tecla Escape: cierra el menú y devuelve el foco al botón
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && mobileMenu.classList.contains('open')) {
    closeMenu();
    hamburger.focus();
  }
});


// ===== 4. ANIMACIÓN AL HACER SCROLL =====
// Los elementos con la clase "reveal" aparecen cuando entran en pantalla.
const revealElements = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        // Cada elemento aparece un poquito después del anterior
        setTimeout(() => entry.target.classList.add('visible'), index * 90);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  revealElements.forEach((element) => observer.observe(element));
} else {
  // Si el navegador es muy viejo, se muestra todo sin animación
  revealElements.forEach((element) => element.classList.add('visible'));
}


// ===== 5. RESALTAR EL DÍA DE HOY EN EL HORARIO =====
const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const today = dayNames[new Date().getDay()];

document.querySelectorAll('.schedule-table tr').forEach((row) => {
  const dayCell = row.cells[0];
  if (dayCell && dayCell.textContent.trim() === today) {
    row.classList.add('schedule-today');
  }
});
