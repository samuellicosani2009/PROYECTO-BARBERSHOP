// =====================================================
// Barber Shop Los Calidosos - JavaScript
// =====================================================


// ===== 1. PANTALLA DE CARGA =====
// Se oculta cuando la página termina de cargar.
// Si algo demora mucho, igual se oculta a los 3.5 segundos.
function hideLoader() {
  const loader = document.getElementById('loader');
  if (loader) {
    loader.classList.add('hidden');
  }
}

window.addEventListener('load', () => setTimeout(hideLoader, 900), { once: true });
setTimeout(hideLoader, 3500);


// ===== 2. BARRA DE NAVEGACIÓN =====
// Cuando se baja un poco la página, la barra se pone con fondo oscuro.
const nav = document.getElementById('nav');

window.addEventListener('scroll', () => {
  nav.classList.toggle('scrolled', window.scrollY > 60);
}, { passive: true });


// ===== 3. MENÚ PARA CELULAR =====
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobile-menu');

// Abre o cierra el menú
function toggleMenu() {
  hamburger.classList.toggle('open');
  mobileMenu.classList.toggle('open');
  hamburger.setAttribute('aria-expanded', mobileMenu.classList.contains('open'));

  // Mientras el menú está abierto no se puede hacer scroll en la página
  document.body.style.overflow = mobileMenu.classList.contains('open') ? 'hidden' : '';
}

// Cierra el menú
function closeMenu() {
  hamburger.classList.remove('open');
  hamburger.setAttribute('aria-expanded', 'false');
  mobileMenu.classList.remove('open');
  document.body.style.overflow = '';
}

// Clic en el botón hamburguesa
hamburger.addEventListener('click', toggleMenu);

// Clic en cualquier enlace del menú: se cierra
document.querySelectorAll('.mobile-menu-link').forEach((link) => {
  link.addEventListener('click', closeMenu);
});

// Tecla Escape: cierra el menú y devuelve el foco al botón
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && mobileMenu.classList.contains('open')) {
    closeMenu();
    hamburger.focus();
  }
});


// ===== 4. ANIMACIÓN AL HACER SCROLL =====
// Los elementos con la clase "reveal" aparecen cuando entran en pantalla.
const revealElements = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        // Cada elemento aparece un poquito después del anterior
        setTimeout(() => entry.target.classList.add('visible'), index * 90);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  revealElements.forEach((element) => observer.observe(element));
} else {
  // Si el navegador es muy viejo, se muestra todo sin animación
  revealElements.forEach((element) => element.classList.add('visible'));
}


// ===== 5. RESALTAR EL DÍA DE HOY EN EL HORARIO =====
const dayNames = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
const today = dayNames[new Date().getDay()];

document.querySelectorAll('.schedule-table tr').forEach((row) => {
  const dayCell = row.cells[0];
  if (dayCell && dayCell.textContent.trim() === today) {
    row.classList.add('schedule-today');
  }
});


// ===== 6. RESERVA DE CITAS =====
// Este código habla con el backend (Flask):
//   - Pide las horas libres cuando se elige fecha y barbero.
//   - Envía los datos del formulario para guardar la cita.
const formReserva = document.getElementById('form-reserva');

// Si la página no tiene el formulario (por ejemplo, la base de datos está caída), no hacemos nada.
if (formReserva) {
  const campoFecha = document.getElementById('reserva-fecha');
  const campoBarbero = document.getElementById('reserva-barbero');
  const campoHora = document.getElementById('reserva-hora');
  const botonReservar = document.getElementById('reserva-enviar');
  const mensajeReserva = document.getElementById('reserva-mensaje');

  // Muestra un mensaje debajo del botón. esError = true lo pone en color de error.
  function mostrarMensaje(texto, esError) {
    mensajeReserva.textContent = texto;
    mensajeReserva.className = 'booking-message ' + (esError ? 'is-error' : 'is-ok');
  }

  // Deja el selector de horas con una sola opción de aviso.
  function avisoEnHoras(texto) {
    campoHora.innerHTML = '';
    campoHora.add(new Option(texto, '', true, true));
    campoHora.options[0].disabled = true;
  }

  // Pide al backend las horas libres de esa fecha y ese barbero.
  async function cargarHoras() {
    const fecha = campoFecha.value;
    const barbero = campoBarbero.value;

    if (!fecha || !barbero) {
      avisoEnHoras('Primero elige la fecha');
      return;
    }

    avisoEnHoras('Buscando horas...');
    try {
      const respuesta = await fetch('/api/horas-disponibles?fecha=' + fecha + '&barbero_id=' + barbero);
      const datos = await respuesta.json();

      // Si mientras tanto la persona cambió la fecha o el barbero, ignoramos esta respuesta vieja.
      if (fecha !== campoFecha.value || barbero !== campoBarbero.value) return;

      if (!respuesta.ok) {
        avisoEnHoras('No se pudieron cargar las horas');
        mostrarMensaje(datos.error, true);
        return;
      }
      if (datos.horas.length === 0) {
        avisoEnHoras('No hay horas libres ese día');
        return;
      }

      campoHora.innerHTML = '';
      campoHora.add(new Option('Elige una hora', '', true, true));
      campoHora.options[0].disabled = true;
      datos.horas.forEach((hora) => campoHora.add(new Option(hora.texto, hora.valor)));
    } catch (error) {
      avisoEnHoras('No se pudieron cargar las horas');
    }
  }

  // Cada vez que cambia la fecha o el barbero, se vuelven a pedir las horas.
  campoFecha.addEventListener('change', cargarHoras);
  campoBarbero.addEventListener('change', cargarHoras);

  // Cuando la persona le da clic a "Reservar cita"
  formReserva.addEventListener('submit', async (evento) => {
    evento.preventDefault(); // evita que la página se recargue

    // Juntamos lo que escribió la persona
    const cita = {
      nombre: document.getElementById('reserva-nombre').value,
      telefono: document.getElementById('reserva-telefono').value,
      correo: document.getElementById('reserva-correo').value,
      servicio_id: document.getElementById('reserva-servicio').value,
      barbero_id: campoBarbero.value,
      fecha: campoFecha.value,
      hora: campoHora.value,
      notas: document.getElementById('reserva-notas').value
    };

    botonReservar.disabled = true; // para que no la envíen dos veces seguidas
    mostrarMensaje('Guardando tu cita...', false);

    try {
      const respuesta = await fetch('/api/citas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cita)
      });
      const resultado = await respuesta.json();

      if (respuesta.ok) {
        formReserva.reset();
        avisoEnHoras('Primero elige la fecha');
        mostrarMensaje(resultado.mensaje, false);
      } else {
        mostrarMensaje(resultado.error, true);
        cargarHoras(); // por si la hora ya la tomó otra persona, se actualiza la lista
      }
    } catch (error) {
      mostrarMensaje('No pudimos conectar con el servidor. Intenta de nuevo o escríbenos por WhatsApp.', true);
    } finally {
      botonReservar.disabled = false;
    }
  });
}
