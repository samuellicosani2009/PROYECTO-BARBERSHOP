# Backend - Barber Shop Los Calidosos

## Qué hace
- Flask muestra tu página en http://127.0.0.1:5000
- Los servicios y el horario salen de la base de datos (PostgreSQL).
- Hay una sección "Reserva tu cita": las citas se guardan en la tabla `citas`.
- Solo se ofrecen las horas libres (según el horario y las citas que ya existen)
  y no se puede reservar dos veces la misma hora con el mismo barbero.
- Si la base de datos falla, la página igual abre y ofrece reservar por WhatsApp.

## Carpetas
- Backend/templates/index.html -> la página (Flask la llena con datos de la base de datos)
- Backend/statics/             -> css, js e img (las usa la página)
- Backend/app.py               -> el servidor y todas las rutas
- Backend/conexion.py          -> la conexión a PostgreSQL
- Backend/crear_tablas.py      -> crea las tablas y los datos iniciales
Los archivos de la carpeta principal (app.py, index.html, css/, js/...) no se usan
con Flask: son tu versión anterior y quedan como respaldo.

## Preparación (una sola vez)
1. Copia `.env.example` y renombra la copia a `.env`.
2. En `.env` escribe tu contraseña de PostgreSQL en DB_PASSWORD y,
   si quieres ver las citas, una clave en CLAVE_ADMIN. No compartas el `.env`.
3. Abre la terminal en la carpeta Backend:
   cd Backend
4. Instala las librerías:
   python -m pip install -r requirements.txt
5. Crea las tablas:
   python crear_tablas.py

## Iniciar
   python app.py
Abre http://127.0.0.1:5000
(Importante: ejecuta el app.py de la carpeta Backend, no el de la carpeta principal.)

## Rutas de la API
- GET  /api/salud                    -> comprueba la conexión
- GET  /api/servicios                -> servicios activos con precio
- GET  /api/horarios                 -> horario de lunes a domingo
- GET  /api/barberos                 -> barberos activos
- GET  /api/horas-disponibles?fecha=2026-12-01&barbero_id=1
- POST /api/citas                    -> guarda una cita (JSON)
- GET  /api/citas?clave=TU_CLAVE     -> lista de citas (solo con la clave del .env)
- GET  /api/tablas y /api/tablas/<nombre> -> tablas públicas (como ya los tenías)

## Cosas que puedes cambiar
- Duración de cada cita y cuántos días adelante se puede reservar: arriba en app.py
  (MINUTOS_POR_CITA y DIAS_MAXIMOS_ADELANTE).
- Precios, descripciones, horario y nombre del barbero: se editan en las tablas
  (por ejemplo desde pgAdmin) y la página se actualiza sola.
- Para ocultar un servicio sin borrarlo: poner `activo = false` en esa fila.
- Para cancelar una cita: poner estado = 'cancelada' (la hora vuelve a quedar libre).
