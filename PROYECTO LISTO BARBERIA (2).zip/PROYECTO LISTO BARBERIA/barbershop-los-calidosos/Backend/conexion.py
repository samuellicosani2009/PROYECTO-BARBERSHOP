import os
import psycopg2
from dotenv import load_dotenv

# Lee las variables guardadas en el archivo .env de la carpeta principal.
load_dotenv()


def conectar():
    """Abre una conexión con la base de datos PostgreSQL."""
    return psycopg2.connect(
        host=os.getenv("DB_HOST", "localhost"),
        database=os.getenv("DB_NAME", "postgres"),
        user=os.getenv("DB_USER", "postgres"),
        password=os.getenv("DB_PASSWORD", "admin"),
        port=os.getenv("DB_PORT", "5432"),
    )
