# crear_tablas.py
# Prepara la base de datos para las reservas:
#   1. Crea las tablas si todavía no existen (NO borra ni cambia nada que ya tengas).
#   2. Revisa que cada tabla tenga las columnas que usa app.py.
#   3. Si las tablas están vacías, agrega los datos iniciales (servicios, horario, barbero).
#
# Se puede ejecutar todas las veces que quieras sin problema.
# Uso:  python crear_tablas.py

from conexion import conectar


# ---------- 1. Las tablas ----------
# "IF NOT EXISTS" significa: créala solo si no existe todavía.
CREAR_TABLAS = """
CREATE TABLE IF NOT EXISTS servicios (
    id          SERIAL PRIMARY KEY,
    nombre      VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio      INTEGER NOT NULL,                 -- precio en pesos colombianos
    destacado   BOOLEAN NOT NULL DEFAULT FALSE,   -- TRUE = sale como "Más popular"
    activo      BOOLEAN NOT NULL DEFAULT TRUE     -- FALSE = no se muestra en la página
);

CREATE TABLE IF NOT EXISTS horarios (
    dia_semana  INTEGER PRIMARY KEY,              -- 0 = Domingo, 1 = Lunes ... 6 = Sábado
    nombre_dia  VARCHAR(20) NOT NULL,
    hora_abre   TIME,
    hora_cierra TIME,
    cerrado     BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS barberos (
    id     SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS clientes (
    id        SERIAL PRIMARY KEY,
    nombre    VARCHAR(100) NOT NULL,
    telefono  VARCHAR(20) NOT NULL,
    correo    VARCHAR(120),
    creado_en TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS citas (
    id          SERIAL PRIMARY KEY,
    cliente_id  INTEGER NOT NULL REFERENCES clientes(id),
    servicio_id INTEGER NOT NULL REFERENCES servicios(id),
    barbero_id  INTEGER NOT NULL REFERENCES barberos(id),
    fecha       DATE NOT NULL,
    hora        TIME NOT NULL,
    estado      VARCHAR(20) NOT NULL DEFAULT 'pendiente',  -- pendiente, confirmada, atendida o cancelada
    notas       TEXT,
    creado_en   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Esto evita que dos personas reserven el mismo barbero, el mismo día y a la misma hora
-- (las citas canceladas no cuentan, así esa hora se puede volver a reservar).
CREATE UNIQUE INDEX IF NOT EXISTS citas_sin_repetir
    ON citas (barbero_id, fecha, hora)
    WHERE estado <> 'cancelada';
"""


# ---------- 2. Columnas que necesita app.py ----------
COLUMNAS_NECESARIAS = {
    "servicios": ["id", "nombre", "descripcion", "precio", "destacado", "activo"],
    "horarios": ["dia_semana", "nombre_dia", "hora_abre", "hora_cierra", "cerrado"],
    "barberos": ["id", "nombre", "activo"],
    "clientes": ["id", "nombre", "telefono", "correo"],
    "citas": ["id", "cliente_id", "servicio_id", "barbero_id", "fecha", "hora", "estado", "notas"],
}


def revisar_columnas(cursor):
    """Compara las columnas reales de cada tabla con las que necesita app.py.
    Devuelve True si todo está bien."""
    todo_bien = True

    for tabla, necesarias in COLUMNAS_NECESARIAS.items():
        cursor.execute(
            """
            SELECT column_name
            FROM information_schema.columns
            WHERE table_schema = 'public' AND table_name = %s
            """,
            (tabla,),
        )
        existentes = [fila[0] for fila in cursor.fetchall()]
        faltan = [columna for columna in necesarias if columna not in existentes]

        if faltan:
            todo_bien = False
            print(f"  [PROBLEMA] La tabla '{tabla}' no tiene estas columnas: {', '.join(faltan)}")
            print(f"             Columnas que tiene ahora: {', '.join(existentes)}")
        else:
            print(f"  [OK] {tabla}")

    return todo_bien


# ---------- 3. Datos iniciales ----------
def tabla_esta_vacia(cursor, tabla):
    cursor.execute(f"SELECT COUNT(*) FROM {tabla}")  # 'tabla' viene de este mismo archivo, no del usuario
    return cursor.fetchone()[0] == 0


def agregar_datos_iniciales(cursor):
    # Servicios: los mismos dos que ya tenías escritos en tu página.
    if tabla_esta_vacia(cursor, "servicios"):
        cursor.execute(
            """
            INSERT INTO servicios (nombre, descripcion, precio, destacado) VALUES
            ('Corte + Barba',
             'El combo completo. Transforma tu look de la cabeza a la barba en una sola visita. Incluye perfilado, degradado y acabado premium.',
             20000, TRUE),
            ('Corte de Cabello',
             'Clásico, fade, texturizado — lo que necesites. Manos expertas con más de 10 años de experiencia. Resultado impecable garantizado.',
             17000, FALSE)
            """
        )
        print("  Servicios agregados (Corte + Barba y Corte de Cabello).")

    # Horario: lunes cerrado, de martes a domingo de 9:00 am a 10:00 pm.
    if tabla_esta_vacia(cursor, "horarios"):
        dias = [(0, "Domingo"), (1, "Lunes"), (2, "Martes"), (3, "Miércoles"),
                (4, "Jueves"), (5, "Viernes"), (6, "Sábado")]
        for numero, nombre in dias:
            if numero == 1:  # lunes
                cursor.execute(
                    "INSERT INTO horarios (dia_semana, nombre_dia, cerrado) VALUES (%s, %s, TRUE)",
                    (numero, nombre),
                )
            else:
                cursor.execute(
                    "INSERT INTO horarios (dia_semana, nombre_dia, hora_abre, hora_cierra, cerrado) "
                    "VALUES (%s, %s, '09:00', '22:00', FALSE)",
                    (numero, nombre),
                )
        print("  Horario agregado (lunes cerrado, martes a domingo 9:00 am - 10:00 pm).")

    # Barbero: pon aquí el nombre real (o cámbialo después desde pgAdmin).
    if tabla_esta_vacia(cursor, "barberos"):
        cursor.execute("INSERT INTO barberos (nombre) VALUES ('Barbero Los Calidosos')")
        print("  Barbero agregado (cambia el nombre en la tabla 'barberos' cuando quieras).")


# ---------- Programa principal ----------
conexion = conectar()
try:
    cursor = conexion.cursor()

    print("Creando tablas que falten...")
    cursor.execute(CREAR_TABLAS)

    print("Revisando columnas...")
    if revisar_columnas(cursor):
        print("Agregando datos iniciales si hacen falta...")
        agregar_datos_iniciales(cursor)
        conexion.commit()
        print("Listo. La base de datos está preparada.")
    else:
        # Si ya tenías una tabla con otras columnas no seguimos: así no se daña nada.
        conexion.rollback()
        print()
        print("No se guardó ningún cambio. Tus tablas ya existen con columnas distintas")
        print("a las que usa el backend. Copia este mensaje y pídele ayuda a tu asistente")
        print("para ajustar el código a tus tablas (o renombra las tablas viejas).")
finally:
    conexion.close()
