import os
import re
from datetime import date, datetime, time, timedelta

from flask import Flask, jsonify, render_template, request
from psycopg2 import errors, sql
from psycopg2.extras import RealDictCursor
from conexion import conectar

# Flask busca las carpetas "templates" y "statics" que están junto a este archivo.
app = Flask(
    __name__,
    template_folder="templates",
    static_folder="statics",
    static_url_path="/static",
)

# Solo exponemos tablas de información pública del negocio.
# No incluimos clientes, citas ni mensajes para no publicar datos personales.
TABLAS_PUBLICAS = {
    "negocio",
    "redes_sociales",
    "horarios",
    "servicios",
    "galeria",
    "barberos",
}

# ---------- Ajustes de las reservas (cámbialos aquí si lo necesitas) ----------
MINUTOS_POR_CITA = 30        # cada cita ocupa un espacio de 30 minutos
DIAS_MAXIMOS_ADELANTE = 60   # no se puede reservar más de 60 días adelante

# Igual que en JavaScript: 0 = Domingo, 1 = Lunes ... 6 = Sábado
NOMBRES_DIAS = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"]

# Si la base de datos falla, la página se sigue viendo con estos datos de respaldo.
SERVICIOS_DE_RESPALDO = [
    {
        "nombre": "Corte + Barba",
        "descripcion": "El combo completo. Transforma tu look de la cabeza a la barba en una sola visita. Incluye perfilado, degradado y acabado premium.",
        "precio_texto": "$20.000",
        "destacado": True,
    },
    {
        "nombre": "Corte de Cabello",
        "descripcion": "Clásico, fade, texturizado — lo que necesites. Manos expertas con más de 10 años de experiencia. Resultado impecable garantizado.",
        "precio_texto": "$17.000",
        "destacado": False,
    },
]
HORARIOS_DE_RESPALDO = [
    {"dia": "Lunes", "cerrado": True, "texto": ""},
    {"dia": "Martes", "cerrado": False, "texto": "9:00 am – 10:00 pm"},
    {"dia": "Miércoles", "cerrado": False, "texto": "9:00 am – 10:00 pm"},
    {"dia": "Jueves", "cerrado": False, "texto": "9:00 am – 10:00 pm"},
    {"dia": "Viernes", "cerrado": False, "texto": "9:00 am – 10:00 pm"},
    {"dia": "Sábado", "cerrado": False, "texto": "9:00 am – 10:00 pm"},
    {"dia": "Domingo", "cerrado": False, "texto": "9:00 am – 10:00 pm"},
]


# =====================================================
# FUNCIONES AYUDANTES (las usan las rutas de más abajo)
# =====================================================

def consultar(sentencia, datos=None):
    """Ejecuta un SELECT y devuelve una lista de diccionarios (una por fila).
    Los %s de la sentencia se llenan con 'datos' (así evitamos inyección SQL).
    Si no mandas 'datos', el símbolo % se queda como está (por ejemplo en '% 7')."""
    conexion = conectar()
    try:
        cursor = conexion.cursor(cursor_factory=RealDictCursor)
        cursor.execute(sentencia, datos)
        return cursor.fetchall()
    finally:
        conexion.close()


def formatear_precio(precio):
    """20000 -> '$20.000'"""
    return "$" + f"{precio:,}".replace(",", ".")


def formatear_hora(hora):
    """time(15, 30) -> '3:30 pm'  (no usamos strftime('%-I') porque no funciona en Windows)"""
    hora_12 = hora.hour % 12
    if hora_12 == 0:
        hora_12 = 12
    sufijo = "am" if hora.hour < 12 else "pm"
    return f"{hora_12}:{hora.minute:02d} {sufijo}"


def leer_fecha(texto):
    """Convierte '2026-11-20' en una fecha. Si el texto no sirve devuelve None."""
    try:
        return datetime.strptime(texto, "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return None


def leer_servicios():
    """Servicios activos, listos para mostrar en la página."""
    servicios = consultar(
        "SELECT id, nombre, descripcion, precio, destacado "
        "FROM servicios WHERE activo = TRUE ORDER BY destacado DESC, id"
    )
    for servicio in servicios:
        servicio["precio_texto"] = formatear_precio(servicio["precio"])
    return servicios


def leer_horarios():
    """Horario de la semana, de lunes a domingo."""
    filas = consultar(
        "SELECT dia_semana, nombre_dia, hora_abre, hora_cierra, cerrado "
        "FROM horarios ORDER BY (dia_semana + 6) % 7"  # esto pone el lunes primero
    )
    horarios = []
    for fila in filas:
        sin_horas = fila["hora_abre"] is None or fila["hora_cierra"] is None
        cerrado = fila["cerrado"] or sin_horas
        texto = ""
        if not cerrado:
            texto = formatear_hora(fila["hora_abre"]) + " – " + formatear_hora(fila["hora_cierra"])
        horarios.append({"dia": fila["nombre_dia"], "cerrado": cerrado, "texto": texto})
    return horarios


def leer_barberos():
    return consultar("SELECT id, nombre FROM barberos WHERE activo = TRUE ORDER BY id")


def calcular_horas_libres(fecha, barbero_id):
    """Devuelve las horas libres de un barbero en una fecha, como lista de
    diccionarios: [{"valor": "15:30", "texto": "3:30 pm"}, ...]"""
    # 1. ¿Abre la barbería ese día de la semana?
    dia = fecha.isoweekday() % 7  # isoweekday: lunes=1 ... domingo=7; con % 7 el domingo queda en 0
    horario = consultar(
        "SELECT hora_abre, hora_cierra, cerrado FROM horarios WHERE dia_semana = %s", (dia,)
    )
    if not horario or horario[0]["cerrado"]:
        return []
    abre = horario[0]["hora_abre"]
    cierra = horario[0]["hora_cierra"]
    if abre is None or cierra is None:
        return []

    # 2. ¿Qué horas ya tiene ocupadas ese barbero ese día? (las canceladas no cuentan)
    citas = consultar(
        "SELECT hora FROM citas WHERE barbero_id = %s AND fecha = %s AND estado <> 'cancelada'",
        (barbero_id, fecha),
    )
    ocupadas = [cita["hora"] for cita in citas]

    # 3. Recorremos el día de 30 en 30 minutos y guardamos las horas que sirven.
    horas = []
    momento = datetime.combine(fecha, abre)
    final = datetime.combine(fecha, cierra)
    ahora = datetime.now()
    while momento + timedelta(minutes=MINUTOS_POR_CITA) <= final:
        ya_paso = momento <= ahora          # si es hoy, no ofrecemos horas que ya pasaron
        esta_ocupada = momento.time() in ocupadas
        if not ya_paso and not esta_ocupada:
            horas.append({"valor": momento.strftime("%H:%M"), "texto": formatear_hora(momento)})
        momento += timedelta(minutes=MINUTOS_POR_CITA)
    return horas


def limpiar_telefono(texto):
    """Deja solo los números y quita el 57 del inicio si lo trae. '+57 316 051 7483' -> '3160517483'"""
    numero = re.sub(r"\D", "", texto)
    if len(numero) == 12 and numero.startswith("57"):
        numero = numero[2:]
    return numero


# =====================================================
# PÁGINA PRINCIPAL
# =====================================================

@app.route("/")
def inicio():
    hoy = date.today()
    try:
        servicios = leer_servicios()
        horarios = leer_horarios()
        barberos = leer_barberos()
        # El formulario solo se muestra si hay servicios y barberos en la base de datos.
        reservas_activas = len(servicios) > 0 and len(barberos) > 0
    except Exception:
        # Si la base de datos falla, la página igual abre con los datos de respaldo.
        app.logger.exception("No fue posible leer la base de datos para la página principal")
        servicios = SERVICIOS_DE_RESPALDO
        horarios = HORARIOS_DE_RESPALDO
        barberos = []
        reservas_activas = False

    return render_template(
        "index.html",
        servicios=servicios,
        horarios=horarios,
        barberos=barberos,
        reservas_activas=reservas_activas,
        fecha_minima=hoy.isoformat(),
        fecha_maxima=(hoy + timedelta(days=DIAS_MAXIMOS_ADELANTE)).isoformat(),
    )


# =====================================================
# RUTAS DE LA API (devuelven JSON)
# =====================================================

@app.route("/api/salud")
def salud():
    """Comprueba que Flask puede conectarse a PostgreSQL."""
    try:
        with conectar() as conexion:
            with conexion.cursor() as cursor:
                cursor.execute("SELECT current_database(), current_user;")
                base, usuario = cursor.fetchone()
        return jsonify({
            "estado": "conectado",
            "base_de_datos": base,
            "usuario": usuario
        })
    except Exception:
        app.logger.exception("No fue posible conectar con PostgreSQL")
        return jsonify({"error": "No fue posible conectar con PostgreSQL"}), 500


@app.route("/api/tablas")
def listar_tablas():
    """Devuelve las tablas públicas permitidas que existen en el esquema public."""
    try:
        with conectar() as conexion:
            with conexion.cursor() as cursor:
                cursor.execute("""
                    SELECT table_name
                    FROM information_schema.tables
                    WHERE table_schema = 'public'
                      AND table_type = 'BASE TABLE'
                    ORDER BY table_name;
                """)
                existentes = [fila[0] for fila in cursor.fetchall()]

        visibles = [nombre for nombre in existentes if nombre in TABLAS_PUBLICAS]
        return jsonify(visibles)
    except Exception:
        app.logger.exception("No fue posible listar las tablas")
        return jsonify({"error": "No fue posible consultar las tablas"}), 500


@app.route("/api/tablas/<nombre>")
def consultar_tabla(nombre):
    """Consulta hasta 100 filas de una tabla pública permitida."""
    if nombre not in TABLAS_PUBLICAS:
        return jsonify({"error": "Esta tabla no está habilitada para consulta"}), 404

    try:
        with conectar() as conexion:
            with conexion.cursor(cursor_factory=RealDictCursor) as cursor:
                consulta = sql.SQL("SELECT * FROM {} LIMIT 100").format(
                    sql.Identifier(nombre)
                )
                cursor.execute(consulta)
                filas = cursor.fetchall()

        # jsonify no sabe convertir las horas (tipo TIME), así que las pasamos a texto.
        for fila in filas:
            for columna, valor in fila.items():
                if isinstance(valor, time):
                    fila[columna] = valor.strftime("%H:%M")

        return jsonify(filas)
    except Exception:
        app.logger.exception("No fue posible consultar la tabla %s", nombre)
        return jsonify({"error": "No fue posible consultar esta tabla"}), 500


@app.route("/api/servicios")
def api_servicios():
    """Lista de servicios activos con su precio."""
    try:
        return jsonify(leer_servicios())
    except Exception:
        app.logger.exception("No fue posible leer los servicios")
        return jsonify({"error": "No fue posible consultar los servicios"}), 500


@app.route("/api/horarios")
def api_horarios():
    """Horario de atención de lunes a domingo."""
    try:
        return jsonify(leer_horarios())
    except Exception:
        app.logger.exception("No fue posible leer los horarios")
        return jsonify({"error": "No fue posible consultar los horarios"}), 500


@app.route("/api/barberos")
def api_barberos():
    """Lista de barberos activos."""
    try:
        return jsonify(leer_barberos())
    except Exception:
        app.logger.exception("No fue posible leer los barberos")
        return jsonify({"error": "No fue posible consultar los barberos"}), 500


@app.route("/api/horas-disponibles")
def horas_disponibles():
    """Horas libres de un barbero en una fecha.
    Se usa así: /api/horas-disponibles?fecha=2026-11-20&barbero_id=1"""
    fecha = leer_fecha(request.args.get("fecha"))
    if fecha is None:
        return jsonify({"error": "La fecha no es válida"}), 400

    try:
        barbero_id = int(request.args.get("barbero_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "Falta elegir el barbero"}), 400

    try:
        horas = calcular_horas_libres(fecha, barbero_id)
        return jsonify({"fecha": fecha.isoformat(), "horas": horas})
    except Exception:
        app.logger.exception("No fue posible calcular las horas disponibles")
        return jsonify({"error": "No fue posible consultar las horas disponibles"}), 500


@app.route("/api/citas", methods=["POST"])
def crear_cita():
    """Guarda una cita nueva. El formulario de la página envía los datos en JSON."""
    datos = request.get_json(silent=True) or {}

    # ---- 1. Leer y validar lo que mandó la persona ----
    nombre = str(datos.get("nombre") or "").strip()
    if len(nombre) < 2 or len(nombre) > 80:
        return jsonify({"error": "Escribe tu nombre (entre 2 y 80 letras)"}), 400

    telefono = limpiar_telefono(str(datos.get("telefono") or ""))
    if len(telefono) != 10:
        return jsonify({"error": "El teléfono debe tener 10 números, por ejemplo 3160517483"}), 400

    correo = str(datos.get("correo") or "").strip()
    if correo == "":
        correo = None  # el correo es opcional
    elif "@" not in correo or len(correo) > 120:
        return jsonify({"error": "El correo no parece válido"}), 400

    notas = str(datos.get("notas") or "").strip()[:300] or None  # opcional, máximo 300 letras

    try:
        servicio_id = int(datos.get("servicio_id"))
        barbero_id = int(datos.get("barbero_id"))
    except (TypeError, ValueError):
        return jsonify({"error": "Elige un servicio y un barbero"}), 400

    fecha = leer_fecha(datos.get("fecha"))
    if fecha is None:
        return jsonify({"error": "Elige una fecha válida"}), 400
    hoy = date.today()
    if fecha < hoy or fecha > hoy + timedelta(days=DIAS_MAXIMOS_ADELANTE):
        return jsonify({"error": f"La fecha debe estar entre hoy y los próximos {DIAS_MAXIMOS_ADELANTE} días"}), 400

    hora_texto = str(datos.get("hora") or "")

    try:
        # ---- 2. Comprobar que el servicio y el barbero existen ----
        if not consultar("SELECT id FROM servicios WHERE id = %s AND activo = TRUE", (servicio_id,)):
            return jsonify({"error": "Ese servicio no existe"}), 400
        if not consultar("SELECT id FROM barberos WHERE id = %s AND activo = TRUE", (barbero_id,)):
            return jsonify({"error": "Ese barbero no existe"}), 400

        # ---- 3. Comprobar que la hora sigue libre ----
        horas_libres = [h["valor"] for h in calcular_horas_libres(fecha, barbero_id)]
        if hora_texto not in horas_libres:
            return jsonify({"error": "Esa hora ya no está disponible. Elige otra, por favor."}), 409
        hora = datetime.strptime(hora_texto, "%H:%M").time()
    except Exception:
        app.logger.exception("No fue posible validar la cita")
        return jsonify({"error": "No fue posible validar la cita"}), 500

    # ---- 4. Guardar: primero el cliente, después la cita ----
    conexion = conectar()
    try:
        cursor = conexion.cursor()

        # Si ya tenemos un cliente con ese teléfono lo reutilizamos; si no, lo creamos.
        cursor.execute("SELECT id FROM clientes WHERE telefono = %s", (telefono,))
        fila = cursor.fetchone()
        if fila:
            cliente_id = fila[0]
            cursor.execute(
                "UPDATE clientes SET nombre = %s, correo = COALESCE(%s, correo) WHERE id = %s",
                (nombre, correo, cliente_id),
            )
        else:
            cursor.execute(
                "INSERT INTO clientes (nombre, telefono, correo) VALUES (%s, %s, %s) RETURNING id",
                (nombre, telefono, correo),
            )
            cliente_id = cursor.fetchone()[0]

        cursor.execute(
            "INSERT INTO citas (cliente_id, servicio_id, barbero_id, fecha, hora, notas) "
            "VALUES (%s, %s, %s, %s, %s, %s) RETURNING id",
            (cliente_id, servicio_id, barbero_id, fecha, hora, notas),
        )
        cita_id = cursor.fetchone()[0]

        conexion.commit()  # hasta aquí no se guarda nada de verdad; commit() lo confirma
    except errors.UniqueViolation:
        # Pasa si otra persona reservó esa misma hora justo en este instante.
        conexion.rollback()
        return jsonify({"error": "Esa hora acaba de ser reservada. Elige otra, por favor."}), 409
    except Exception:
        conexion.rollback()  # si algo falla, deshacemos todo para no dejar datos a medias
        app.logger.exception("No fue posible guardar la cita")
        return jsonify({"error": "No fue posible guardar la cita. Intenta de nuevo."}), 500
    finally:
        conexion.close()

    mensaje = (
        f"¡Listo, {nombre}! Tu cita quedó para el {fecha.strftime('%d/%m/%Y')} "
        f"a las {formatear_hora(hora)}. Te esperamos en Cra 36 #48a-17."
    )
    return jsonify({"mensaje": mensaje, "cita_id": cita_id}), 201


@app.route("/api/citas")
def ver_citas():
    """Lista de citas, solo para el dueño. Hay que mandar la clave secreta:
    /api/citas?clave=TU_CLAVE      (opcional: &fecha=2026-11-20 para ver un solo día)
    La clave se escribe en el archivo .env como CLAVE_ADMIN."""
    clave_correcta = os.getenv("CLAVE_ADMIN")
    if not clave_correcta or request.args.get("clave") != clave_correcta:
        return jsonify({"error": "No autorizado"}), 403

    sentencia = """
        SELECT c.id,
               to_char(c.fecha, 'YYYY-MM-DD') AS fecha,
               to_char(c.hora, 'HH24:MI') AS hora,
               c.estado,
               cl.nombre AS cliente,
               cl.telefono,
               s.nombre AS servicio,
               b.nombre AS barbero,
               c.notas
        FROM citas c
        JOIN clientes cl ON cl.id = c.cliente_id
        JOIN servicios s ON s.id = c.servicio_id
        JOIN barberos b ON b.id = c.barbero_id
    """
    datos = None
    fecha = leer_fecha(request.args.get("fecha"))
    if fecha is not None:
        sentencia += " WHERE c.fecha = %s"
        datos = (fecha,)
    sentencia += " ORDER BY c.fecha, c.hora LIMIT 200"

    try:
        return jsonify(consultar(sentencia, datos))
    except Exception:
        app.logger.exception("No fue posible leer las citas")
        return jsonify({"error": "No fue posible consultar las citas"}), 500


if __name__ == "__main__":
    app.run(debug=True)
