
from flask import Flask, jsonify
import psycopg2

app = Flask(__name__)

def conectar():
    return psycopg2.connect(
        host="localhost",
        database="postgres",
        user="postgres",
        password="admin",
        port="5432"
    )

@app.route("/")
def inicio():
    return """
    <h1>Barber Shop Los Calidosos</h1>
    <h2>Tablas de PostgreSQL</h2>
    <p>Consulta tus tablas aquí:</p>
    <ul id="tablas"></ul>

    <script>
    fetch('/api/tablas')
      .then(respuesta => respuesta.json())
      .then(datos => {
        const lista = document.getElementById('tablas');
        datos.forEach(tabla => {
          const elemento = document.createElement('li');
          elemento.textContent = tabla;
          lista.appendChild(elemento);
        });
      })
      .catch(error => console.error('Error:', error));
    </script>
    """

@app.route("/api/tablas")
def mostrar_tablas():
    conexion = conectar()
    cursor = conexion.cursor()

    cursor.execute("""
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
        ORDER BY table_name;
    """)

    tablas = [fila[0] for fila in cursor.fetchall()]

    cursor.close()
    conexion.close()

    return jsonify(tablas)

if __name__ == "__main__":
    app.run(debug=True)
