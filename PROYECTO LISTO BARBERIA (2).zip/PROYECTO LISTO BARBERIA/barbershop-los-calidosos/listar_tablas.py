import psycopg2

conexion = psycopg2.connect(
    host="localhost",
    database="postgres",
    user="postgres",
    password="admin",
    port="5432"
)

cursor = conexion.cursor()

cursor.execute("""
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = 'public'
    ORDER BY table_name;
""")

for tabla in cursor.fetchall():
    print(tabla[0])

cursor.close()
conexion.close()