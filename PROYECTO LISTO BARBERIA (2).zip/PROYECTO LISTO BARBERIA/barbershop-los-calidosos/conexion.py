
import psycopg2

try:
    conexion = psycopg2.connect(
        host="localhost",
        database="postgres",
        user="postgres",
        password="admin",
        port="5432"
    )

    print("¡CONEXIÓN EXITOSA CON POSTGRESQL!")

    cursor = conexion.cursor()
    cursor.execute("SELECT current_database();")

    print("Base de datos conectada:", cursor.fetchone()[0])

    cursor.close()
    conexion.close()

except Exception as error:
    print("Error de conexión:", repr(error))
